using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Item_Ability;
public class Data_Game_Inventory : Data_Game {
    public Inventory Save_Inventory;
    public Inventory Save_Storage;
    
    public override void On_Start_Save () {
       // Debug.Log ("Saving xx");
        base.On_Start_Save ();
         string [] Host_Server_Value = new string [13]; // 1 For Id *3 for (table,title,value) *2 for (Id & Own)
            string [] Host_Server_Field = new string [13];
            Convert_Item_Effect Ci = new Convert_Item_Effect ();
            Host_Server_Field[0] = "Id";Host_Server_Value[0] = Data_Game_Utama.Ins._Data_Game_Account.Id;
            Host_Server_Field[1] = "table_1";Host_Server_Value[1] = "Db_Inventory";
            Host_Server_Field[2] = "title_1";Host_Server_Value[2] = "Slot_1";
            Host_Server_Field[3] = "value_1";Host_Server_Value[3] = Fungsi_Umum.Ins._A_String_Umum.On_A_String_To_String (Save_Inventory.Item_Id);

            Host_Server_Field[4] = "table_2";Host_Server_Value[4] = "Db_Inventory";
            Host_Server_Field[5] = "title_2";Host_Server_Value[5] = "Own_1";
            Host_Server_Field[6] = "value_2";Host_Server_Value[6] = Fungsi_Umum.Ins._A_String_Umum.On_A_String_To_String (Ci.Combine_A_Int_Own_And_A_String_Status (Save_Inventory.Item_Own, Save_Inventory.Item_Status));

            Host_Server_Field[7] = "table_3";Host_Server_Value[7] = "Db_Storage";
            Host_Server_Field[8] = "title_3";Host_Server_Value[8] = "Slot_1";
            Host_Server_Field[9] = "value_3";Host_Server_Value[9] = Fungsi_Umum.Ins._A_String_Umum.On_A_String_To_String (Save_Storage.Item_Id);

            Host_Server_Field[10] = "table_4";Host_Server_Value[10] = "Db_Storage";
            Host_Server_Field[11] = "title_4";Host_Server_Value[11] = "Own_1";
           // Host_Server_Field[12] = "value_4";Host_Server_Value[12] = Fungsi_Umum.Ins._A_Int_Umum.On_A_Int_To_String (Save_Storage.Item_Own);
            Host_Server_Field[12] = "value_4";Host_Server_Value[12] = Fungsi_Umum.Ins._A_String_Umum.On_A_String_To_String (Ci.Combine_A_Int_Own_And_A_String_Status (Save_Storage.Item_Own, Save_Storage.Item_Status));

        System_Settings.Ins.On_Host_Server_GO ("Save_Status", "Write_All_Table_Value_Fix", Host_Server_Field, Host_Server_Value, this); 
//        Debug.Log ("Saving xxx");
    }

    public override void On_Finish_Save () {
        base.On_Finish_Save ();
    }

    public override void On_Start_Load (string Id) {
        base.On_Start_Load (Id);
        string [] Host_Server_Field = new string [2]; Host_Server_Field[0] = "Id"; Host_Server_Field[1] = "Table";
        string [] Host_Server_Value = new string [2]; Host_Server_Value[0] = Id; Host_Server_Value[1] = "Db_Inventory";
        System_Settings.Ins.On_Host_Server_GO ("Load_Db_Deck", "Read_All_Table_1", Host_Server_Field, Host_Server_Value, this);
    }

    public override void On_Finish_Load () {
        base.On_Finish_Load ();
        Data_Game_Utama.Ins._Data_Game_Source.On_Send_Data_To_Inventory (Load_Status_Result);
    }

    public override void On_LHS_Load_Status (string [] Res) {
        base.On_LHS_Load_Status (Res);
        /*
            Load_Status_Result = Res;
            if (Res[0] == "Failed") {
                Data_Game_Utama.Ins._Data_Game_Source.On_Failed_Load (this);
            } else if (Res[0] == "Success") {
                On_Finish_Load ();
            }
            */
    }
}
