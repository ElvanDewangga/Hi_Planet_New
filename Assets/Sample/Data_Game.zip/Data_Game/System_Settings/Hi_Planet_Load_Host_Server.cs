using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Hi_Planet_Load_Host_Server : Load_Host_Server
{
    // Start is called before the first frame update
    void Start() {
        
    }

    // Update is called once per frame
    void Update()
    {
        
    }
}
